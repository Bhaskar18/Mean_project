
// Module declaration here
//oitzero's angular wrapper for sweetalert
var myApp = angular.module("cart",
	["ngRoute","ngAnimate","oitozero.ngSweetAlert"]);
